This project is done with python programming language
in order for it to run please run the following commands in your python terminal (while on project directory)

"pip install requirements.txt"
 if it fails run these two..
 "pip install pyqt5"
 "pip install pyqt5-tools"

to run the project the correct way run the main function from the class main.py

Note:-
You play with blue
And ai plays with red

Easy takes avg of 10 seconds to find next move
Med takes avg of 1 minute to find next move
Hard takes avg of 5 minutes to find next move

Minmax Heuristic:-
The function evalBoard() in the controller takes a player and returns the sum of distances of each player piece to the furthest 
vertex of the goal reigon ([0, 12] for Human, and [16, 12] for AI)

The minmax function evaluates state of the board by subtracting human's score and AI score and returns
so a negative state signfies a bad state for AI as human is closer to goal than AI in that case and vice verca

Team members Emails -> Names -> IDs

peteratefnagiub@gmail.com -> Peter Atef -> ID 20190140
omar.atef.2001@gmail.com  -> Omar Atef -> ID 20190356
omarkhaledm21@gmail.com   -> Omar Khaled Mohy -> ID 20190353
Omar Khaled Al Haj -> 20190351
Abdelrahman Ali -> 20190314

